<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="csrf_token" content="{{ csrf_token() }}" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" charset="utf-8">
<meta name="description" content="A micro-blogging system built with love and laravel">
<meta name="robots" content="index, nofollow">
<link rel="stylesheet" type="text/css" href="{{URL::asset('css/app.css')}}">
<link rel="icon" type="image/x-icon" href="{{URL::asset('favicon.ico')}}">
<script type="text/javascript" src="{{URL::asset('js/jquery.min.js')}}"></script>  
